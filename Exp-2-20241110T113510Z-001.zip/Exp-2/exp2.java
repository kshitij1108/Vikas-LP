import java.io.*;

class exp2 {
    public static void main(String args[]) throws Exception {
        FileReader FP = new FileReader(args[0]);
        BufferedReader bufferedReader = new BufferedReader(FP);

        String line = null;
        int line_count = 0, LC = 0, symTabLine = 0, opTabLine = 0, litTabLine = 0, poolTabLine = 0;

        // Data Structures
        final int MAX = 100;
        String SymbolTab[][] = new String[MAX][3];
        String OpTab[][] = new String[MAX][3];
        String LitTab[][] = new String[MAX][2];
        int PoolTab[] = new int[MAX];
        int litTabAddress = 0;

        System.out.println("___________________________________________________");

        while ((line = bufferedReader.readLine()) != null) {
            String[] tokens = line.split("\t");

            if (tokens.length > 2 && line_count == 0) {
                LC = 100; // Start address at 100 to match expected output
                for (int i = 0; i < tokens.length; i++)
                    System.out.print(tokens[i] + "\t");
                System.out.println("");
            } else if (line_count > 0) {
                for (int i = 0; i < tokens.length; i++)
                    System.out.print(tokens[i] + "\t");
                System.out.println("");

                if (tokens.length > 0 && !tokens[0].equals("")) {
                    // Avoid duplicate entries in Symbol Table
                    boolean isDuplicate = false;
                    for (int i = 0; i < symTabLine; i++) {
                        if (SymbolTab[i][0] != null && SymbolTab[i][0].equals(tokens[0])) {
                            isDuplicate = true;
                            break;
                        }
                    }
                    if (!isDuplicate) {
                        SymbolTab[symTabLine][0] = tokens[0];
                        SymbolTab[symTabLine][1] = Integer.toString(LC);
                        SymbolTab[symTabLine][2] = Integer.toString(1);
                        symTabLine++;
                    }
                }

                if (tokens.length > 1) {
                    // Only add valid mnemonics to OpTab
                    if (!tokens[1].trim().isEmpty()) {
                        OpTab[opTabLine][0] = tokens[1];

                        if (tokens[1].equalsIgnoreCase("START") || tokens[1].equalsIgnoreCase("END")
                                || tokens[1].equalsIgnoreCase("ORIGIN") || tokens[1].equalsIgnoreCase("EQU")
                                || tokens[1].equalsIgnoreCase("LTORG")) {
                            OpTab[opTabLine][1] = "AD";
                            OpTab[opTabLine][2] = "R11";
                            opTabLine++;
                        } else if (tokens[1].equalsIgnoreCase("DS") || tokens[1].equalsIgnoreCase("DC")) {
                            OpTab[opTabLine][1] = "DL";
                            OpTab[opTabLine][2] = "R7";
                            opTabLine++;
                        } else if (!tokens[1].trim().isEmpty()) {
                            OpTab[opTabLine][1] = "IS";
                            OpTab[opTabLine][2] = "(04,1)";
                            opTabLine++;
                        }
                    }
                }

                if (tokens.length == 3 && tokens[2].charAt(0) == '=') {
                    LitTab[litTabLine][0] = tokens[2];
                    LitTab[litTabLine][1] = Integer.toString(LC);
                    litTabLine++;
                }
            }
            line_count++;
            LC++;
        }

        System.out.println("___________________________________________________");

        // Print Symbol Table with proper formatting
        System.out.println("\nSYMBOL TABLE");
        System.out.println("--------------------------");
        System.out.println("SYMBOL\t\tADDRESS\t\tLENGTH");
        System.out.println("--------------------------");
        for (int i = 0; i < symTabLine; i++)
            System.out.printf("%-8s\t%-8s\t%-8s\n", SymbolTab[i][0], SymbolTab[i][1], SymbolTab[i][2]);
        System.out.println("--------------------------");

        // Print Opcode Table with proper formatting
        System.out.println("\n\t\tOPCODE TABLE");
        System.out.println("----------------------------");
        System.out.println("MNEMONIC\tCLASS\tINFO");
        System.out.println("----------------------------");
        for (int i = 0; i < opTabLine; i++) {
            if (OpTab[i][0] != null && !OpTab[i][0].trim().isEmpty()) {
                System.out.printf("%-12s\t%-8s\t%-8s\n", OpTab[i][0], OpTab[i][1], OpTab[i][2]);
            }
        }
        System.out.println("----------------------------");

        // Print Literal Table
        System.out.println("\n   LITERAL TABLE");
        System.out.println("-----------------");
        System.out.println("LITERAL\tADDRESS");
        System.out.println("-----------------");
        for (int i = 0; i < litTabLine; i++)
            System.out.printf("%-8s\t%-8s\n", LitTab[i][0], LitTab[i][1]);
        System.out.println("------------------");

        // Pool Table logic and printing
        poolTabLine = 0;
        for (int i = 0; i < litTabLine; i++) {
            if (i == 0 || (Integer.parseInt(LitTab[i][1]) > Integer.parseInt(LitTab[i-1][1]) + 1)) {
                PoolTab[poolTabLine++] = i + 1;
            }
        }

        System.out.println("\n   POOL TABLE");
        System.out.println("-----------------");
        System.out.println("LITERAL NUMBER");
        System.out.println("-----------------");
        for (int i = 0; i < poolTabLine; i++)
            System.out.println(PoolTab[i]);
        System.out.println("------------------");

        bufferedReader.close();
    }
}