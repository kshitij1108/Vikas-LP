#include<stdio.h>

int main() {
    int p[20], bt[20], pri[20], wt[20], tat[20], n, i, k, temp;
    float wtavg = 0, tatavg = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    // Input burst times and priorities for each process
    printf("\nEnter Burst Time and Priority for each process:\n");
    for(i = 0; i < n; i++) {
        p[i] = i + 1; // Process numbers from 1 to n
        printf("Process %d: ", p[i]);
        scanf("%d %d", &bt[i], &pri[i]);
    }

    // Sort processes based on priority using Bubble Sort
    for(i = 0; i < n - 1; i++) {
        for(k = 0; k < n - i - 1; k++) {
            if(pri[k] > pri[k + 1]) {
                // Swap priorities
                temp = pri[k];
                pri[k] = pri[k + 1];
                pri[k + 1] = temp;

                // Swap burst times
                temp = bt[k];
                bt[k] = bt[k + 1];
                bt[k + 1] = temp;

                // Swap process numbers accordingly
                temp = p[k];
                p[k] = p[k + 1];
                p[k + 1] = temp;
            }
        }
    }

    // Calculate waiting time and turnaround time for each process
    wt[0] = 0; // First process has 0 waiting time
    for(i = 1; i < n; i++) {
        wt[i] = 0;
        for(k = 0; k < i; k++) {
            wt[i] += bt[k];
        }
    }

    // Calculate turnaround time for each process
    for(i = 0; i < n; i++) {
        tat[i] = bt[i] + wt[i];
    }

    // Calculate average waiting time and average turnaround time
    for(i = 0; i < n; i++) {
        wtavg += wt[i];
        tatavg += tat[i];
    }
    wtavg /= n;
    tatavg /= n;

    // Display results
    printf("\nPROCESS\t\tPRIORITY\tBURST TIME\tWAITING TIME\tTURNAROUND TIME\n");
    for(i = 0; i < n; i++) {
        printf("P%d\t\t%d\t\t%d\t\t%d\t\t%d\n", p[i], pri[i], bt[i], wt[i], tat[i]);
    }
    printf("\nAverage Waiting Time: %.2f", wtavg);
    printf("\nAverage Turnaround Time: %.2f\n", tatavg);

    return 0;
}
