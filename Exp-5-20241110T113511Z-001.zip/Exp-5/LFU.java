import java.util.Scanner;

public class LFU{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] rs = new int[50];
        int[] cntr = new int[20];
        int[] a = new int[20];
        int m, f, pf = 0;
        
        System.out.print("Enter number of page references: ");
        m = scanner.nextInt();
        System.out.print("Enter the reference string: ");
        for (int i = 0; i < m; i++) {
            rs[i] = scanner.nextInt();
        }
        System.out.print("Enter the available number of frames: ");
        f = scanner.nextInt();
        for (int i = 0; i < f; i++) {
            cntr[i] = 0;
            a[i] = -1; 
        }
        System.out.println("\nThe Page Replacement Process is:");
        for (int i = 0; i < m; i++) {
            boolean pageFound = false;
            for (int j = 0; j < f; j++) {
                if (rs[i] == a[j]) {
                    cntr[j]++; 
                    pageFound = true;
                    break;
                }
            }
            if (!pageFound) {
                int min = 0;
                for (int k = 1; k < f; k++) {
                    if (cntr[k] < cntr[min]) {
                        min = k;
                    }
                }
                a[min] = rs[i];
                cntr[min] = 1; 
                pf++; 
            }
            for (int j = 0; j < f; j++) {
                System.out.print(a[j] + "\t");
            }
            if (!pageFound) {
                System.out.print("\tPF No. " + pf);
            }
            System.out.println();
        }
        System.out.println("\nTotal number of page faults: " + pf);
        scanner.close();
    }
}
