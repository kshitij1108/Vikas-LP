#include <iostream>
#include <vector>
#include <limits> // for std::numeric_limits

#define MAX 25

int main() {
    std::vector<int> frag(MAX, 0), b(MAX, 0), f(MAX, 0);
    std::vector<int> bf(MAX, 0), ff(MAX, 0);

    int nb, nf, temp, lowest = std::numeric_limits<int>::max();

    // Input number of blocks and files
    std::cout << "\nEnter the number of blocks: ";
    std::cin >> nb;
    std::cout << "Enter the number of files: ";
    std::cin >> nf;

    // Input block sizes
    std::cout << "\nEnter the size of the blocks:-\n";
    for (int i = 1; i <= nb; ++i) {
        std::cout << "Block " << i << ": ";
        std::cin >> b[i];
    }

    // Input file sizes
    std::cout << "Enter the size of the files :-\n";
    for (int i = 1; i <= nf; ++i) {
        std::cout << "File " << i << ": ";
        std::cin >> f[i];
    }

    // First Fit Memory Allocation with Best Fit Calculation
    for (int i = 1; i <= nf; ++i) {
        lowest = std::numeric_limits<int>::max();
        for (int j = 1; j <= nb; ++j) {
            if (bf[j] != 1) {
                temp = b[j] - f[i];
                if (temp >= 0 && lowest > temp) {
                    ff[i] = j;
                    lowest = temp;
                }
            }
        }
        frag[i] = lowest;
        bf[ff[i]] = 1;
    }

    // Output the results
    std::cout << "\nFile No\tFile Size \tBlock No\tBlock Size\tFragment";
    for (int i = 1; i <= nf && ff[i] != 0; ++i) {
        std::cout << "\n" << i << "\t\t" << f[i] << "\t\t" << ff[i] << "\t\t" << b[ff[i]] << "\t\t" << frag[i];
    }

    return 0;
}
